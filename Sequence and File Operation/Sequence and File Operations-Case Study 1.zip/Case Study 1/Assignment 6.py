# Please write a program which accepts a string from console and print it in reverse order.

s = input("enter a sentence: ")
print(s[::-1])
