d ={"john":40, "peter":45}
print(list(d.keys()))

# output should be list of keys
# ['john', 'peter']