# Write a for loop that prints all elements of a list and their position in the list.
a = [4, 7, 3, 2, 5, 9]
i = 0
for i in (range(len(a))):
    print(f"At position a[{i}] is {a[i]}")
