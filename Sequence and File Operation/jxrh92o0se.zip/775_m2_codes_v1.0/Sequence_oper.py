list=["Marketing","Content Designing","Sales"]
print(list)

#Concatenation
print(list+["Python","Hadoop"])

#Repetition
print(list*2)

#Membership Testing
print('Marketing' in list)

#Indexing
print(list[2])

#Slicing
print(list[0:2])

