#tuple in set
dict={1:(1,2,3),2:(3,4,5)}
print(dict)
print(dict[1][1])


#list in set
dict={1:["Python","Java"],2:[1,3,5,7]}
print(dict)
print(dict[1][0])

