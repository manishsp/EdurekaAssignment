str=input("Enter your input")
print("Received input is: ",str)


# Example

name=input("Enter your name")

age=input("Enter your age")

print("Welcome ",name)
print("Your age is ",age)

print("After 5 years, your age will be :",(int(age)+5))